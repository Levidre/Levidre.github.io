This balloon is an Invader Zim one. It's a supplemental balloon for people finding the font of the Zim and GIR default balloon hard to read or who just prefer a more simple balloon. 
It contains the Irken font to install and an other font called Astron. It's not necessary to install the second font as it has been modified to increase the distance between letters and lines and doesn't need to be installed to be used.

The main font used is a modified version of the Astron font you can found on https://www.cufonfonts.com/font/astron


