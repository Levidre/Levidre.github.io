This balloon is an Invader Zim one. It's installed with the Zim ukagaka. 
It contains two fonts to install. The first one is the Irken font and the second one is a version modified of the Invader Zim font with the size of the letters made constant, punctuations size increased and parenthesis added. Its name being INVADER-modified, it won't replace an other version installed.


